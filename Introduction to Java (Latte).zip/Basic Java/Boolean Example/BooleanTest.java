public class BooleanTest extends ConsoleProgram
{
    public void run()
    {
        boolean isStudent = false;
        System.out.println("Is student: " + isStudent);
    }
}