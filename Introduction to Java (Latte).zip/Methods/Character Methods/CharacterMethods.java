public class CharacterMethods extends ConsoleProgram
{
    public void run()
    {
        char ch = 'f';
        
        if(Character.isUpperCase(ch))
        {
            System.out.println("It is uppercase!");
        }
        else
        {
            System.out.println("It is not uppercase");
        }
        
        
    }
}