public class Multiply extends ConsoleProgram
{
    public void run()
    {
        multiply(2, 20);
        multiply(5, 19);
        multiply(100, 15);
        
    }
    
    private void multiply(int a, int b)
    {
        // Your code here. 
        int product = a * b;
        // Print out the product of a and b.
        System.out.println(product);
    }
}