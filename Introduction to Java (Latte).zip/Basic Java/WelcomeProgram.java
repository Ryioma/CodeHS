public class Welcome extends ConsoleProgram
{
    public void run()
    {
        System.out.println("my name is Jeremy");
        System.out.println("I enjoy comedy");
    } 
}