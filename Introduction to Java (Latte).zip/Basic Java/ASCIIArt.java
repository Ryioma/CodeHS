public class Art extends ConsoleProgram{

    public void run()
    {
        // Your code here
        System.out.println("   /)___");
        System.out.println("  /     O|___");
        System.out.println(" /           )");
        System.out.println("/       )___/");
    }

}