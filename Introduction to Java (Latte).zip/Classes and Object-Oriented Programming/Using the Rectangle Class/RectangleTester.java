public class RectangleTester extends ConsoleProgram
{
    public void run()
    {
        // Create a rectangle with width 5 and height 12
        Rectangle Tumeric = new Rectangle(5,12);
        System.out.println(Tumeric);
        
    }
}