public class ForLoop extends ConsoleProgram
{
    public void run()
    {
        for(int i = 0; i < 10; i++)
        {
            System.out.println(i);
        }
    }
}