public class AddFractions extends ConsoleProgram
{
    public void run()
    {
        int firstnum = readInt("What is the numerator of the first fraction? ");
        int firstden = readInt("What is the denominator of the first fraction? ");
        int secondnum = readInt("What is the numerator of the second fraction? ");
        int secondden = readInt("What is the denominator of the second fraction? ");
        
        int denans = firstden * secondden;
        int numans = firstnum * secondden + secondnum * firstden;
        
        System.out.println("The sum of " + firstnum + "/" + firstden + " + " + secondnum + "/" + secondden + " = " + numans + "/" + denans);
    }
}