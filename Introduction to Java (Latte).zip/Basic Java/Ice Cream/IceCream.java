public class IceCream extends ConsoleProgram
{
    public void run()
    {
        boolean q = readBoolean("Do you like ice cream? ");
        boolean likes = q;
        System.out.println(likes);
        
    }
}