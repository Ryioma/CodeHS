public class WhileLoop extends ConsoleProgram
{
    public void run()
    {
        int i = 10;
        
        while(i >= 0)
        {
            System.out.println(i);
            i--;
        }
    }
}