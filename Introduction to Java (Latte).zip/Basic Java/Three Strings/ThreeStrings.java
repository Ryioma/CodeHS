public class ThreeStrings extends ConsoleProgram
{
    public void run()
    {
        // Ask the user for three strings.
        // remember to use the readLine() method.
        String x = readLine("First String? ");
        String y = readLine("Second String? ");
        String z = readLine("Third String? ");
        String xy = x + y;
        
        if(xy.equals(z))
        {
            System.out.println(x + " + " + y + " is equal to " + z + "!");
        }
        else
        {
            System.out.println(x + " + " + y + " is not equal to " + z + "!");
        }
    }
}