public class Factorial extends ConsoleProgram
{

    public void run()
    {
        int product = 1;
        int IVEBEENONTHISQUESTIONFORWAYTOOLONG = readInt("What number would you like to compute the factorial for? "); 
        int IHATETHISQUESTION = 1;
    	for(int i = IHATETHISQUESTION; i <= IVEBEENONTHISQUESTIONFORWAYTOOLONG; i++)
    	{
    		product *= i;
    	}
    	
    	System.out.println(product);
    }
}