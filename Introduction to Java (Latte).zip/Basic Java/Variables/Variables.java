public class Variables extends ConsoleProgram
{

    public void run()
    {
        int snapchatsSent = 353;
        System.out.println("Number of snapchats sent: " + snapchatsSent);
        
        double youTubeVideosWatched = 130.5;
        System.out.println("Number of YouTube videos watched: " + youTubeVideosWatched);
        
        String favoriteApp = "Instagram";
        System.out.println("Favorite app: " + favoriteApp);
        
        youTubeVideosWatched = 240.4;
        
        System.out.println("Number of YouTube videos watched: " + youTubeVideosWatched);
        
        char firstLetter = 'A';
        System.out.println("First letter " + firstLetter);
    }

}