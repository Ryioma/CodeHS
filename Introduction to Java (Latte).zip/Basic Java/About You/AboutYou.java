public class AboutYou extends ConsoleProgram
{
    public void run()
    {
        String food = readLine("What is your favorite food? ");
        String color = readLine("What is your favorite color? ");
        String movie = readLine("What is your favorite movie? ");
        
        System.out.println(food);
        System.out.println(color);
        System.out.println(movie);
    }
}