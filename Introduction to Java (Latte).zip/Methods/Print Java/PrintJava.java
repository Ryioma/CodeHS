public class PrintJava extends ConsoleProgram
{
    public void run()
    {
        // You need to write `printJ`
        printJ();
        System.out.println();
        printA();
        System.out.println();
        printV();
        System.out.println();
        printA();
    }
    
    private void printJ()
    {
        // Fill this in
        System.out.println("    *");
        System.out.println("    *");
        System.out.println("    *");
        System.out.println("*   *");
        System.out.println("*****");
    }
    
    private void printA()
    {
        System.out.println("*****");
        System.out.println("*   *");
        System.out.println("*****");
        System.out.println("*   *");
        System.out.println("*   *");
    }
    
    private void printV()
    {
        System.out.println("*   *");
        System.out.println("*   *");
        System.out.println(" * * ");
        System.out.println("  *  ");
    }
}