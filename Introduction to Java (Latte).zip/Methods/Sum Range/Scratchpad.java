public int sumFrom(int a, int b)
{
    for (int i = a + 1; i <= b; i++)
    {
        a += i;
    }
    
    return a;
}
