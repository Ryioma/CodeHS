public class Variables extends ConsoleProgram
{

    public void run()
    {
        String myName = "Karel the Dog";
        int luckyNumber = 11;
        double currentTemperature = 75.3;
        boolean isStudent = true;
        
        System.out.println(myName);
        System.out.println(luckyNumber);
        System.out.println(currentTemperature);
        System.out.println(isStudent);
    }
}