public class Messages extends ConsoleProgram
{
    public void run()
    {
        // Your code here.
        TextMessage Bart = new TextMessage("Bart", "Lisa", "Where are you?");
        TextMessage Lisa = new TextMessage("Lisa", "Bart", "I'm at school!");
    
        System.out.println(Bart);
        System.out.println(Lisa);
        // Create the two TextMessage objects and print them out.
    }
}