public class Variables extends ConsoleProgram
{

    public void run()
    {
        // your code here
        int year = 2024;
        System.out.println("The current year is " + year);
    }

}