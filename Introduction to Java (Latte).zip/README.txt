MY CODEHS EXERCISES
-------------------

What Is This?
-------------
This folder contains the code for all of your completed
coding exercises for the 'Introduction to Java (Latte)' course.
Each exercise is saved in its own file with the exercise 
name as the name of the file. 

How Do I Use This Code?
-----------------------
You can open and edit your downloaded code files in a text
editor. Note that any changes you make to your downloaded
code will not be saved to your code on the CodeHS website.
For more information on how to put your code into your own
website, visit the CodeHS page for that exercise, select
the 'More' tab, then click 'Embed'.

Please send in any feedback or suggestions to hello@codehs.com