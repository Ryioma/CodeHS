public class Poetry extends ConsoleProgram
{
    public void run()
    {
        System.out.println("shizukasaya");
        System.out.println("iwanishimiiru");
        System.out.println("seminokoe");
    
        System.out.println("Crunchy chewy");
        System.out.println("Awesome");
        System.out.println("Nice and sweet");
        System.out.println("Delightful and delicious");
        System.out.println("Yummy treat");
    
        String poem = readLine("Type your own poem here: ");
        System.out.println(poem);
    }
}