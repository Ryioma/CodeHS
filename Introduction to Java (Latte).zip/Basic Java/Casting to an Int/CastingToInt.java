public class CastingToInt extends ConsoleProgram
{
    public void run()
    {
        double pi = 3.14;
        int pie = (int) pi;
        
        System.out.println(pie);
    }
}