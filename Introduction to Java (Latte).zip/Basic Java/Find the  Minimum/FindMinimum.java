public class FindMinimum extends ConsoleProgram
{
    public void run()
    {
        // Ask the user for three ints and 
        // print out the minimum.
        int Anthony = readInt("Enter first number: ");
        int M = readInt("Enter second number: ");
        int TUMERIC = readInt("Enter third number: ");
        
        if(Anthony < M && Anthony < TUMERIC)
        {
            System.out.println(Anthony);
        }
        if(M < Anthony && M < TUMERIC)
        {
            System.out.println(M);
        } else
        {
            System.out.println(TUMERIC);
        }
        
    }
}