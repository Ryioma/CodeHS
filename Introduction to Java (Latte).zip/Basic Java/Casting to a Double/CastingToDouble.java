public class CastingToDouble extends ConsoleProgram
{
    public void run()
    {
        int num1 = 4;
        int num2 = 3;
        
        double ans = num2 / (double) num1;
        System.out.println(ans);
    }
}