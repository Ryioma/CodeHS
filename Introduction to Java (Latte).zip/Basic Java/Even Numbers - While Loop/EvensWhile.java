public class EvensWhile extends ConsoleProgram
{
    public void run()
    {
        int Anthony = 0;
        int Tumeric = 500;
        while(Anthony <= Tumeric)
        {
            System.out.println(Anthony);
            Anthony += 2;
        }
    }
}