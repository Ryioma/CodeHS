public class LineBreak extends ConsoleProgram
{
    public void run()
    {
        System.out.println("Part 1");
        printLineBreak();
        
        System.out.println("Part 2");
        printLineBreak();
    }
    
    private void printLineBreak()
    {
        System.out.println("==========");
        System.out.println("**********");
    }
}