public class CountByTwos extends ConsoleProgram
{
    public void run()
    {
    	for(int i = 0; i <= 100; i += 2)
    	{
		    System.out.println(i);
    	}
	}  
}