public class Repeat1000 extends ConsoleProgram
{
    public void run()
    {
     for(int i = 0; i < 1000; i++)
       {
            System.out.println("Hello Karel");
       }
    }
}