public class StudentTester extends ConsoleProgram
{
    public void run()
    {
        Student alan = new Student("Alan", "Turing", 11);
        Student ada = new Student("Ada", "Lovelace", 12);
        Student Anthony = new Student("Anthony", "Tumeric", 15);
        // Add an entry for yourself here!
        
        System.out.println(alan);
        System.out.println(ada);
        System.out.println(Anthony);
        // Print out your student object
        

    }
}